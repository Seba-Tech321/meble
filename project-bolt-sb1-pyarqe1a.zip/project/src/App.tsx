import { useState, useEffect } from 'react';
import {
  ShoppingCart,
  ArrowLeft,
  ArrowRight,
  ChevronRight,
  Phone,
  Mail,
  X,
  Check,
} from 'lucide-react';

// Types
interface Product {
  id: string;
  title: string;
  price: number;
  category: string;
  categorySlug: string;
  images: string[];
  colors: string[];
  sizes: string[];
  finishes: string[];
  dimensions: string;
  specs: string;
  description: string;
}

interface CartItem {
  id: string;
  product: Product;
  color: string;
  size: string;
  finish: string;
  quantity: number;
}

interface Category {
  name: string;
  slug: string;
  image: string;
}

// Data
const categories: Category[] = [
  { name: 'Szafki łazienkowe', slug: 'bathroom', image: 'https://source.unsplash.com/800x1000/?bright,minimalist,bathroom,interior,white' },
  { name: 'Szafki kuchenne', slug: 'kitchen-cabinets', image: 'https://source.unsplash.com/800x1000/?modern,kitchen,cabinets,interior,minimal' },
  { name: 'Szafki nocne', slug: 'nightstands', image: 'https://source.unsplash.com/800x1000/?serene,bedroom,nightstand,interior,cozy' },
  { name: 'Szafy do sypialni', slug: 'wardrobes', image: 'https://source.unsplash.com/800x1000/?minimalist,bedroom,wardrobe,closet,serene' },
  { name: 'Sprzęt RTV / AGD', slug: 'appliances', image: 'https://source.unsplash.com/800x1000/?modern,kitchen,appliances,oven,cooktop' },
  { name: 'Kuchnie na wymiar', slug: 'custom-kitchen', image: 'https://source.unsplash.com/800x1000/?luxury,custom,kitchen,interior,design' },
];

const products: Product[] = [
  {
    id: 'bathroom-1',
    title: 'Szafka pod umywalkę Slim',
    price: 799,
    category: 'Szafki łazienkowe',
    categorySlug: 'bathroom',
    images: [
      'https://source.unsplash.com/800x800/?modern,bathroom,vanity,cabinet',
      'https://source.unsplash.com/800x800/?bathroom,sink,cabinet',
      'https://source.unsplash.com/800x800/?bathroom,storage,drawers',
    ],
    colors: ['Jasnoszary', 'Ciemnoszary', 'Biały'],
    sizes: ['60 cm', '80 cm', '100 cm'],
    finishes: ['Matowe', 'Wysoki połysk'],
    dimensions: 'Szerokość: 60cm, Wysokość: 45cm, Głębokość: 35cm',
    specs: 'Materiał: płyta laminowana 18mm, fronty MDF lakierowane, zawiasy z wolnym domykiem, regulowane nogi.',
    description: 'Minimalistyczna szafka łazienkowa z dwiema głębokimi szufladami. Wykonana z wodoodpornych materiałów premium, idealna do nowoczesnych, jasnych łazienek.',
  },
  {
    id: 'bathroom-2',
    title: 'Szafka wisząca MirrorGloss',
    price: 949,
    category: 'Szafki łazienkowe',
    categorySlug: 'bathroom',
    images: [
      'https://source.unsplash.com/800x800/?bathroom,mirror,cabinet,led',
      'https://source.unsplash.com/800x800/?bathroom,lighted,mirror',
      'https://source.unsplash.com/800x800/?bathroom,glossy,cabinet',
    ],
    colors: ['Biały', 'Jasnoszary', 'Antracyt'],
    sizes: ['60 cm', '80 cm', '100 cm'],
    finishes: ['Matowe', 'Wysoki połysk'],
    dimensions: 'Szerokość: 60cm, Wysokość: 20cm, Głębokość: 80cm',
    specs: 'Zintegrowane lustro z oświetleniem LED, dotykowy włącznik, półki wewnętrzne z hartowanego szkła, system cichego domyku.',
    description: 'Elegancka szafka łazienkowa z frontami na wysoki połysk i wbudowanym, dyskretnym podświetleniem LED, które nadaje wnętrzu luksusowy charakter.',
  },
  {
    id: 'kitchen-cabinet-1',
    title: 'Szafka wisząca Cargo (Kuchnia)',
    price: 450,
    category: 'Szafki kuchenne',
    categorySlug: 'kitchen-cabinets',
    images: [
      'https://source.unsplash.com/800x800/?modern,kitchen,cabinet,pantry',
      'https://source.unsplash.com/800x800/?kitchen,storage,shelf',
      'https://source.unsplash.com/800x800/?kitchen,organized,cabinet',
    ],
    colors: ['Jasnoszary', 'Ciemnoszary', 'Biały'],
    sizes: ['60 cm', '80 cm', '100 cm'],
    finishes: ['Matowe', 'Wysoki połysk'],
    dimensions: 'Szerokość: 80cm, Wysokość: 70cm, Głębokość: 30cm',
    specs: 'Płyta meblowa 16mm, system szuflad tandembox, prowadnice z pełnym wysuwem, możliwość montażu na ścianie.',
    description: 'Funkcjonalna szafka kuchenna z nowoczesnym systemem wysuwnym Cargo. Pozwala na maksymalne zagospodarowanie przestrzeni spiżarnianej.',
  },
  {
    id: 'kitchen-cabinet-2',
    title: 'Szafka dolna z szufladami Premium',
    price: 620,
    category: 'Szafki kuchenne',
    categorySlug: 'kitchen-cabinets',
    images: [
      'https://source.unsplash.com/800x800/?kitchen,drawers,cabinet,closing',
      'https://source.unsplash.com/800x800/?kitchen,soft,close,drawers',
      'https://source.unsplash.com/800x800/?kitchen,base,cabinet',
    ],
    colors: ['Biały', 'Jasnoszary', 'Dąb naturalny'],
    sizes: ['60 cm', '80 cm', '100 cm'],
    finishes: ['Matowe', 'Wysoki połysk'],
    dimensions: 'Szerokość: 60cm, Wysokość: 60cm, Głębokość: 82cm',
    specs: 'Płyta laminowana 18mm, 3 szuflady z systemem soft-close, prowadnice ball-bearing, regulowane nogi 10-15cm.',
    description: 'Solidna szafka stojąca wyposażona w system cichego domyku (soft-close). Wytrzymałe szuflady pomieszczą nawet najcięższe akcesoria kuchenne.',
  },
  {
    id: 'nightstand-1',
    title: 'Stolik nocny Gray',
    price: 399,
    category: 'Szafki nocne',
    categorySlug: 'nightstands',
    images: [
      'https://source.unsplash.com/800x800/?gray,nightstand,bedroom',
      'https://source.unsplash.com/800x800/?bedside,table,gray',
      'https://source.unsplash.com/800x800/?bedroom,nightstand,minimal',
    ],
    colors: ['Jasnoszary', 'Ciemnoszary', 'Biały'],
    sizes: ['60 cm', '80 cm', '100 cm'],
    finishes: ['Matowe', 'Wysoki połysk'],
    dimensions: 'Szerokość: 50cm, Wysokość: 55cm, Głębokość: 40cm',
    specs: 'Korpus płyta laminowana 18mm, fronty fornirowane dąb naturalny, nóżki metalowe czarne matowe.',
    description: 'Kompaktowy stolik nocny w odcieniu gołębiej szarości. Wyposażony w jedną pojemną szufladę na najpotrzebniejsze drobiazgi.',
  },
  {
    id: 'nightstand-2',
    title: 'Stolik nocny Loft Wood',
    price: 480,
    category: 'Szafki nocne',
    categorySlug: 'nightstands',
    images: [
      'https://source.unsplash.com/800x800/?industrial,loft,nightstand,oak',
      'https://source.unsplash.com/800x800/?bedside,metal,wood,table',
      'https://source.unsplash.com/800x800/?industrial,nightstand,bedroom',
    ],
    colors: ['Dąb naturalny', 'Orzech', 'Biały'],
    sizes: ['60 cm', '80 cm', '100 cm'],
    finishes: ['Matowe', 'Wysoki połysk'],
    dimensions: 'Szerokość: 45cm, Wysokość: 40cm, Głębokość: 55cm',
    specs: 'Czarna metalowa rama stalowa, szuflada dębowa z prowadnicami soft-close, półka otwarta, maksymalne obciążenie 30kg.',
    description: 'Designerski stolik nocny łączący surowość czarnego metalu z ciepłem naturalnego dębu. Idealny akcent do sypialni w stylu industrialnym.',
  },
  {
    id: 'wardrobe-1',
    title: 'Szafa przesuwna Mirror',
    price: 1899,
    category: 'Szafy do sypialni',
    categorySlug: 'wardrobes',
    images: [
      'https://source.unsplash.com/800x800/?wardrobe,sliding,mirror,doors',
      'https://source.unsplash.com/800x800/?closet,mirror,sliding',
      'https://source.unsplash.com/800x800/?bedroom,wardrobe,mirror',
    ],
    colors: ['Jasnoszary', 'Ciemnoszary', 'Biały'],
    sizes: ['60 cm', '80 cm', '100 cm'],
    finishes: ['Matowe', 'Wysoki połysk'],
    dimensions: 'Szerokość: 200cm, Wysokość: 220cm, Głębokość: 62cm',
    specs: 'System przesuwny blumotion, lustra w kolorze brązowym lub grafitowym, wnętrze: drążki, półki, szuflady do wyboru.',
    description: 'Pojemna szafa do sypialni z dużymi lustrzanymi frontami, które optycznie powiększą każde pomieszczenie. Wygodne drzwi przesuwne oszczędzają miejsce.',
  },
  {
    id: 'wardrobe-2',
    title: 'Szafa TRZYDRZWIOWA Grande',
    price: 2399,
    category: 'Szafy do sypialni',
    categorySlug: 'wardrobes',
    images: [
      'https://source.unsplash.com/800x800/?large,bedroom,wardrobe,closet',
      'https://source.unsplash.com/800x800/?big,wardrobe,furniture',
      'https://source.unsplash.com/800x800/?bedroom,closet,storage',
    ],
    colors: ['Biały', 'Jasnoszary', 'Antracyt'],
    sizes: ['60 cm', '80 cm', '100 cm'],
    finishes: ['Matowe', 'Wysoki połysk'],
    dimensions: 'Szerokość: 200cm, Wysokość: 65cm, Głębokość: 220cm',
    specs: 'Trzy skrzydła, wewnętrzny system drążków do wieszania, regulowane półki, szuflady z organizatorami, zawiasy z cichym domykiem.',
    description: 'Monumentalna szafa ubraniowa z klasycznie otwieranymi drzwiami. Wnętrze skrywa drążki na wieszaki oraz rząd głębokich półek organizacyjnych.',
  },
  {
    id: 'appliance-1',
    title: 'Okap podtynkowy Silent',
    price: 699,
    category: 'Sprzęt RTV / AGD',
    categorySlug: 'appliances',
    images: [
      'https://source.unsplash.com/800x800/?modern,kitchen,cooker,hood',
      'https://source.unsplash.com/800x800/?kitchen,hood,extractor',
      'https://source.unsplash.com/800x800/?kitchen,ventilation,modern',
    ],
    colors: ['Jasnoszary', 'Ciemnoszary', 'Biały'],
    sizes: ['60 cm', '80 cm', '100 cm'],
    finishes: ['Matowe', 'Wysoki połysk'],
    dimensions: 'Szerokość: 60cm, Wysokość: 28cm, Głębokość: 30cm',
    specs: 'Wydajność: 450m³/h, poziom hałasu: 45dB, oświetlenie LED, sterowanie dotykowe, filtr aluminiowy w zestawie.',
    description: 'Nowoczesny okap kuchenny przeznaczony do pełnej zabudowy szafkowej. Pracuje niezwykle cicho, skutecznie oczyszczając powietrze z zapachów.',
  },
  {
    id: 'appliance-2',
    title: 'Kuchenka elektryczna / Płyta Indigo',
    price: 1499,
    category: 'Sprzęt RTV / AGD',
    categorySlug: 'appliances',
    images: [
      'https://source.unsplash.com/800x800/?induction,cooktop,electric,hob',
      'https://source.unsplash.com/800x800/?kitchen,stove,induction',
      'https://source.unsplash.com/800x800/?electric,stovetop,modern',
    ],
    colors: ['Jasnoszary', 'Ciemnoszary', 'Biały'],
    sizes: ['60 cm', '80 cm', '100 cm'],
    finishes: ['Matowe', 'Wysoki połysk'],
    dimensions: 'Szerokość: 60cm, Wysokość: 85cm, Głębokość: 60cm',
    specs: '4 pola grzejne, piekarnik elektryczny 65L, klasa energetyczna A+, termostat, sygnał dźwiękowy, drzwi chłodzone.',
    description: 'Zaawansowana płyta indukcyjna z intuicyjnym panelem dotykowym. Posiada funkcję szybkiego nagrzewania oraz blokadę bezpieczeństwa przed dziećmi.',
  },
  {
    id: 'appliance-3',
    title: 'Piekarnik do zabudowy EcoCook',
    price: 1699,
    category: 'Sprzęt RTV / AGD',
    categorySlug: 'appliances',
    images: [
      'https://source.unsplash.com/800x800/?built,in,electric,oven,black',
      'https://source.unsplash.com/800x800/?kitchen,oven,modern',
      'https://source.unsplash.com/800x800/?built,in,oven,stainless',
    ],
    colors: ['Czarny', 'Nierdzewny stal', 'Biały'],
    sizes: ['60 cm', '80 cm', '100 cm'],
    finishes: ['Matowe', 'Wysoki połysk'],
    dimensions: 'Szerokość: 60cm, Wysokość: 60cm, Głębokość: 55cm',
    specs: 'Czarne szkło hartowane, panel dotykowy smart, 10 programów pieczenia, termoobieg, klasa energetyczna A++, oświetlenie LED wewnątrz.',
    description: 'Energooszczędny piekarnik elektryczny wykończony eleganckim, ciemnoszarym szkłem. Wyposażony w termoobieg oraz funkcję czyszczenia parowego.',
  },
];

type ViewType = 'home' | 'categories' | 'products' | 'product-detail' | 'cart' | 'custom-kitchen';

function App() {
  const [view, setView] = useState<ViewType>('home');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [selectedColor, setSelectedColor] = useState('');
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedFinish, setSelectedFinish] = useState('');
  const [showThankYou, setShowThankYou] = useState(false);

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
  });

  const [selectedPayment, setSelectedPayment] = useState<string>('');

  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [view]);

  const handleCategoryClick = (slug: string) => {
    if (slug === 'custom-kitchen') {
      setView('custom-kitchen');
    } else {
      setSelectedCategory(slug);
      setView('products');
    }
  };

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setCurrentImageIndex(0);
    setSelectedColor(product.colors[0]);
    setSelectedSize(product.sizes[0]);
    setSelectedFinish(product.finishes[0]);
    setView('product-detail');
  };

  const addToCart = () => {
    if (!selectedProduct) return;

    const existingItem = cart.find(
      (item) =>
        item.id === selectedProduct.id &&
        item.color === selectedColor &&
        item.size === selectedSize &&
        item.finish === selectedFinish
    );

    if (existingItem) {
      setCart(
        cart.map((item) =>
          item.id === selectedProduct.id &&
          item.color === selectedColor &&
          item.size === selectedSize &&
          item.finish === selectedFinish
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      );
    } else {
      setCart([
        ...cart,
        {
          id: selectedProduct.id,
          product: selectedProduct,
          color: selectedColor,
          size: selectedSize,
          finish: selectedFinish,
          quantity: 1,
        },
      ]);
    }
  };

  const removeFromCart = (id: string, color: string, size: string, finish: string) => {
    setCart(cart.filter((item) => !(item.id === id && item.color === color && item.size === size && item.finish === finish)));
  };

  const getSubtotal = () => {
    return cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  };

  const handleCheckout = () => {
    setCart([]);
    setFormData({ name: '', email: '', phone: '', address: '' });
    setSelectedPayment('');
    setShowThankYou(true);
  };

  const closeThankYou = () => {
    setShowThankYou(false);
    setView('home');
  };

  // Header Component
  const Header = () => (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-[#EBEBE7]">
      <div className="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16">
        <div className="flex items-center justify-between h-20">
          <button
            onClick={() => setView('home')}
            className="text-2xl font-light tracking-[0.15em] text-[#222222] hover:opacity-70 transition-opacity duration-500"
          >
            MebleMini.
          </button>

          <div className="flex items-center gap-10">
            <nav className="hidden md:flex items-center gap-10">
              <button
                onClick={() => setView('categories')}
                className="text-sm font-light tracking-wide text-[#666666] hover:text-[#222222] transition-colors duration-500"
              >
                Kolekcja
              </button>
              <button
                onClick={() => setView('products')}
                className="text-sm font-light tracking-wide text-[#666666] hover:text-[#222222] transition-colors duration-500"
              >
                Produkty
              </button>
            </nav>

            <button
              onClick={() => setView('cart')}
              className="relative p-3 rounded-xl hover:bg-[#F7F7F5] transition-all duration-500"
            >
              <ShoppingCart className="w-5 h-5 text-[#222222]" />
              {cartItemCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-[#222222] text-white text-xs rounded-full flex items-center justify-center font-medium">
                  {cartItemCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );

  // Footer Component
  const Footer = () => (
    <footer className="bg-[#F7F7F5] border-t border-[#EBEBE7] mt-auto">
      <div className="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16 py-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
          {/* Left Column - Brand */}
          <div>
            <h3 className="text-2xl font-light tracking-[0.15em] text-[#222222] mb-6">MebleMini.</h3>
            <p className="text-sm font-light leading-relaxed text-[#666666]">
              Tworzymy przestrzenie, które kochasz. Minimalistyczne, zrównoważone meble. Podnosimy jakość codziennego życia dzięki przemyślanemu designowi.
            </p>
            <p className="text-xs font-light text-[#999999] mt-8">
              &copy; 2024 MebleMini. Wszelkie prawa zastrzeżone.
            </p>
          </div>

          {/* Middle Column - Shop */}
          <div>
            <h4 className="text-xs font-normal uppercase tracking-[0.2em] text-[#222222] mb-8">
              Sklep
            </h4>
            <ul className="space-y-4">
              {categories.slice(0, 5).map((cat) => (
                <li key={cat.slug}>
                  <button
                    onClick={() => handleCategoryClick(cat.slug)}
                    className="text-sm font-light text-[#666666] hover:text-[#222222] transition-colors duration-500"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Right Column - Support */}
          <div>
            <h4 className="text-xs font-normal uppercase tracking-[0.2em] text-[#222222] mb-8">
              Wsparcie / Kontakt
            </h4>
            <ul className="space-y-4 mb-8">
              <li>
                <button className="text-sm font-light text-[#666666] hover:text-[#222222] transition-colors duration-500">
                  Kontakt
                </button>
              </li>
              <li>
                <button className="text-sm font-light text-[#666666] hover:text-[#222222] transition-colors duration-500">
                  Dostawa i zwroty
                </button>
              </li>
              <li>
                <button className="text-sm font-light text-[#666666] hover:text-[#222222] transition-colors duration-500">
                  FAQ
                </button>
              </li>
            </ul>

            <div className="space-y-3 text-sm font-light text-[#666666]">
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4" />
                <span>+48 123 456 789</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4" />
                <span>kontakt@meblemini.pl</span>
              </div>
            </div>

            <div className="flex gap-5 mt-8">
              <a href="#" className="text-[#CCCCCC] hover:text-[#222222] transition-colors duration-500">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.06 1.88 2.89 2.89 0 012.32-5.02V9.41a6.1 6.1 0 00-5.06 6.09 6.12 6.12 0 006.11 6.11 6.12 6.12 0 006.11-6.11V9.11a7.93 7.93 0 003.77 1.11V6.69h-.9z"/>
                </svg>
              </a>
              <a href="#" className="text-[#CCCCCC] hover:text-[#222222] transition-colors duration-500">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.354.2-6.782 2.618-6.982 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.354 2.617 6.781 6.982 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.98-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>
              <a href="#" className="text-[#CCCCCC] hover:text-[#222222] transition-colors duration-500">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231 5.45-6.231zm-1.161 17.52h1.833L7.084 4.126H5.117L17.083 19.77z"/>
                </svg>
              </a>
            </div>

            <div className="flex gap-6 mt-10 text-xs font-light text-[#999999]">
              <button className="hover:text-[#222222] transition-colors duration-500">Polityka prywatności</button>
              <span>|</span>
              <button className="hover:text-[#222222] transition-colors duration-500">Regulamin</button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );

  // Home Page (Step 1)
  const HomePage = () => (
    <div className="relative h-screen w-full overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage:
            'url("https://source.unsplash.com/1920x1080/?luxury,minimalist,living,room,interior,design")',
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/50 via-black/25 to-transparent" />

      <div className="relative h-full flex items-center">
        <div className="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16 w-full">
          <div className="max-w-2xl">
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-extralight tracking-tight text-white leading-[1.1] mb-8">
              Meble zaprojektowane do życia, stworzone dla Ciebie.
            </h1>
            <p className="text-lg sm:text-xl font-light text-white/80 mb-12 leading-relaxed">
              Odkryj naszą kolekcję minimalistycznych, ponadczasowych mebli wykonanych z myślą o jakości i premium materiałach.
            </p>
            <button
              onClick={() => setView('categories')}
              className="inline-flex items-center gap-3 px-10 py-5 bg-white text-[#222222] rounded-[12px] font-light tracking-wide hover:bg-[#F7F7F5] transition-all duration-500 hover:shadow-[0_15px_50px_rgba(255,255,255,0.15)]"
            >
              Zobacz kolekcję
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  // Categories Page (Step 2) - Luxury Boutique Style
  const CategoriesPage = () => (
    <div className="min-h-screen pt-32 pb-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16">
        <div className="text-center mb-20">
          <h1 className="text-4xl sm:text-5xl font-extralight tracking-tight text-[#222222] mb-6">
            Nasze Kolekcje
          </h1>
          <p className="text-base font-light text-[#666666] max-w-2xl mx-auto leading-relaxed">
            Wybierz kategorię, aby odkryć nasze produkty
          </p>
        </div>

        {/* Luxury vertically-oriented card layout */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {categories.map((category) => (
            <button
              key={category.slug}
              onClick={() => handleCategoryClick(category.slug)}
              className="group relative aspect-[3/4] rounded-[12px] overflow-hidden transition-all duration-500 hover:shadow-[0_20px_60px_rgba(0,0,0,0.08)]"
            >
              {/* Background Image with zoom on hover */}
              <div
                className="absolute inset-0 bg-cover bg-center transition-transform duration-700 ease-out group-hover:scale-105"
                style={{ backgroundImage: `url("${category.image}")` }}
              />
              {/* Soft gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
              {/* Category title at absolute bottom */}
              <div className="absolute bottom-0 left-0 right-0 p-6 text-center">
                <h3 className="text-lg font-light tracking-[0.1em] text-white">{category.name}</h3>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );

  // Custom Kitchen Page - Complete Overhaul
  const CustomKitchenPage = () => (
    <div className="min-h-screen pt-32 pb-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16">
        <button
          onClick={() => setView('categories')}
          className="flex items-center gap-3 text-[#666666] hover:text-[#222222] mb-16 transition-colors duration-500 font-light"
        >
          <ArrowLeft className="w-5 h-5" />
          Powrót do kategorii
        </button>

        {/* Header */}
        <div className="text-center mb-20">
          <h1 className="text-4xl sm:text-5xl font-extralight tracking-tight text-[#222222] mb-6">
            Kuchnie na wymiar
          </h1>
        </div>

        {/* Center section with CTA button */}
        <div className="flex flex-col items-center justify-center mb-16">
          {/* Minimalist CTA Button */}
          <button
            onClick={() => {
              alert('Wpisz swój numer telefonu, a nasz projektant oddzwoni do Ciebie w ciągu 15 minut');
            }}
            className="px-16 py-6 bg-transparent border-2 border-[#666666] text-[#666666] rounded-[12px] font-light tracking-wide text-lg transition-all duration-300 hover:bg-[#222222] hover:border-[#222222] hover:text-white"
          >
            Umów spotkanie telefoniczne
          </button>

          {/* Elegant sub-text caption */}
          <p className="mt-10 text-sm font-light text-[#999999] max-w-xl text-center leading-relaxed">
            Każda kuchnia jest unikalnym projektem stworzonym specjalnie dla Ciebie. Nasz zespół projektantów
            poprowadzi Cię przez cały proces - od pierwszej konsultacji, przez dobór materiałów premium,
            aż po finalną realizację. Skontaktuj się z nami, aby rozpocząć tworzenie kuchni Twoich marzeń.
          </p>
        </div>

        {/* Inspirational full-width kitchen image */}
        <div className="w-full aspect-[21/9] rounded-[12px] overflow-hidden mb-16">
          <div
            className="w-full h-full bg-cover bg-center"
            style={{
              backgroundImage: `url("https://source.unsplash.com/1920x800/?luxury,modern,kitchen,interior,design,marble")`
            }}
          />
        </div>

        {/* Additional design details */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
          <div className="p-8">
            <h3 className="text-sm font-normal uppercase tracking-[0.2em] text-[#222222] mb-4">Projektowanie</h3>
            <p className="text-sm font-light text-[#666666] leading-relaxed">
              Indywidualne projekty 3D dopasowane do Twojej przestrzeni i stylu życia.
            </p>
          </div>
          <div className="p-8">
            <h3 className="text-sm font-normal uppercase tracking-[0.2em] text-[#222222] mb-4">Materiały Premium</h3>
            <p className="text-sm font-light text-[#666666] leading-relaxed">
              Najwyższej jakości forniry, kamienie naturalne i akcesoria renomowanych marek.
            </p>
          </div>
          <div className="p-8">
            <h3 className="text-sm font-normal uppercase tracking-[0.2em] text-[#222222] mb-4">Montaż</h3>
            <p className="text-sm font-light text-[#666666] leading-relaxed">
              Profesjonalny montaż realizowany przez doświadczonych fachowców.
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  // Products Page (Step 3)
  const ProductsPage = () => {
    const filteredProducts = selectedCategory
      ? products.filter((p) => p.categorySlug === selectedCategory)
      : products;

    const categoryName = selectedCategory
      ? categories.find((c) => c.slug === selectedCategory)?.name || 'Wszystkie produkty'
      : 'Wszystkie produkty';

    return (
      <div className="min-h-screen pt-32 pb-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16">
          <div className="mb-16">
            <button
              onClick={() => setView('categories')}
              className="flex items-center gap-3 text-[#666666] hover:text-[#222222] mb-6 transition-colors duration-500 font-light"
            >
              <ArrowLeft className="w-5 h-5" />
              Powrót do kategorii
            </button>
            <h1 className="text-4xl sm:text-5xl font-extralight tracking-tight text-[#222222]">{categoryName}</h1>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="group bg-[#F7F7F5] rounded-[12px] overflow-hidden transition-all duration-500 hover:shadow-ambient-hover cursor-pointer"
                onClick={() => handleProductClick(product)}
              >
                <div className="aspect-square overflow-hidden">
                  <div
                    className="w-full h-full bg-cover bg-center transition-transform duration-700 group-hover:scale-105"
                    style={{ backgroundImage: `url("${product.images[0]}")` }}
                  />
                </div>
                <div className="p-6">
                  <span className="text-xs font-light tracking-[0.15em] text-[#999999] uppercase">
                    {product.category}
                  </span>
                  <h3 className="text-lg font-light text-[#222222] mt-2 mb-3">{product.title}</h3>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-light text-[#222222]">{product.price} zł</span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleProductClick(product);
                      }}
                      className="text-sm font-light text-[#666666] hover:text-[#222222] transition-colors duration-500"
                    >
                      Zobacz szczegóły
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  // Product Detail Page (Step 4)
  const ProductDetailPage = () => {
    if (!selectedProduct) return null;

    return (
      <div className="min-h-screen pt-32 pb-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16">
          <button
            onClick={() =>
              selectedCategory ? setView('products') : setView('categories')
            }
            className="flex items-center gap-3 text-[#666666] hover:text-[#222222] mb-16 transition-colors duration-500 font-light"
          >
            <ArrowLeft className="w-5 h-5" />
            Powrót do produktów
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
            {/* Image Gallery */}
            <div className="relative">
              <div className="aspect-square rounded-[12px] overflow-hidden bg-[#F7F7F5] shadow-ambient">
                <div
                  className="w-full h-full bg-cover bg-center transition-opacity duration-500"
                  style={{ backgroundImage: `url("${selectedProduct.images[currentImageIndex]}")` }}
                />
              </div>

              {/* Navigation Arrows */}
              <button
                onClick={() =>
                  setCurrentImageIndex(
                    currentImageIndex === 0
                      ? selectedProduct.images.length - 1
                      : currentImageIndex - 1
                  )
                }
                className="absolute left-5 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/95 backdrop-blur-md rounded-full flex items-center justify-center shadow-ambient hover:bg-white transition-all duration-500 hover:shadow-ambient-hover"
              >
                <ArrowLeft className="w-5 h-5 text-[#222222]" />
              </button>
              <button
                onClick={() =>
                  setCurrentImageIndex(
                    currentImageIndex === selectedProduct.images.length - 1
                      ? 0
                      : currentImageIndex + 1
                  )
                }
                className="absolute right-5 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/95 backdrop-blur-md rounded-full flex items-center justify-center shadow-ambient hover:bg-white transition-all duration-500 hover:shadow-ambient-hover"
              >
                <ArrowRight className="w-5 h-5 text-[#222222]" />
              </button>

              {/* Thumbnails */}
              <div className="flex gap-4 mt-6">
                {selectedProduct.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentImageIndex(idx)}
                    className={`w-20 h-20 rounded-[12px] overflow-hidden transition-all duration-500 ${
                      currentImageIndex === idx
                        ? 'ring-2 ring-[#222222]'
                        : 'opacity-50 hover:opacity-100'
                    }`}
                  >
                    <div
                      className="w-full h-full bg-cover bg-center"
                      style={{ backgroundImage: `url("${img}")` }}
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Info */}
            <div className="lg:pl-8">
              <span className="text-xs font-light tracking-[0.2em] text-[#999999] uppercase">
                {selectedProduct.category}
              </span>
              <h1 className="text-4xl sm:text-5xl font-extralight tracking-tight text-[#222222] mt-4 mb-6">
                {selectedProduct.title}
              </h1>
              <p className="text-base font-light text-[#666666] mb-8 leading-relaxed">{selectedProduct.description}</p>
              <p className="text-3xl font-light text-[#222222] mb-12">{selectedProduct.price} zł</p>

              {/* Color Selection */}
              <div className="mb-12">
                <h3 className="text-xs font-normal uppercase tracking-[0.2em] text-[#222222] mb-5">
                  Kolor
                </h3>
                <div className="flex flex-wrap gap-4">
                  {selectedProduct.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`px-6 py-4 rounded-[12px] text-sm font-light transition-all duration-500 ${
                        selectedColor === color
                          ? 'bg-[#222222] text-white'
                          : 'bg-[#F7F7F5] text-[#222222] hover:bg-[#EBEBE7]'
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Selection */}
              <div className="mb-12">
                <h3 className="text-xs font-normal uppercase tracking-[0.2em] text-[#222222] mb-5">
                  Rozmiar
                </h3>
                <div className="flex flex-wrap gap-4">
                  {selectedProduct.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`px-6 py-4 rounded-[12px] text-sm font-light transition-all duration-500 ${
                        selectedSize === size
                          ? 'bg-[#222222] text-white'
                          : 'bg-[#F7F7F5] text-[#222222] hover:bg-[#EBEBE7]'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>

              {/* Finish Selection */}
              <div className="mb-12">
                <h3 className="text-xs font-normal uppercase tracking-[0.2em] text-[#222222] mb-5">
                  Wykończenie frontu
                </h3>
                <div className="flex flex-wrap gap-4">
                  {selectedProduct.finishes.map((finish) => (
                    <button
                      key={finish}
                      onClick={() => setSelectedFinish(finish)}
                      className={`px-6 py-4 rounded-[12px] text-sm font-light transition-all duration-500 ${
                        selectedFinish === finish
                          ? 'bg-[#222222] text-white'
                          : 'bg-[#F7F7F5] text-[#222222] hover:bg-[#EBEBE7]'
                      }`}
                    >
                      {finish}
                    </button>
                  ))}
                </div>
              </div>

              {/* Delivery Info */}
              <div className="bg-[#F7F7F5] rounded-[12px] p-6 mb-12">
                <p className="text-sm font-light text-[#666666]">
                  <span className="font-normal text-[#222222]">Wysyłka w 24h</span>, koszt dostawy: 49 zł
                </p>
              </div>

              {/* Dimensions */}
              <div className="mb-12">
                <h3 className="text-xs font-normal uppercase tracking-[0.2em] text-[#222222] mb-5">
                  Wymiary
                </h3>
                <p className="text-sm font-light text-[#666666] leading-relaxed">{selectedProduct.dimensions}</p>
              </div>

              {/* Specs */}
              <div className="mb-12">
                <h3 className="text-xs font-normal uppercase tracking-[0.2em] text-[#222222] mb-5">
                  Specyfikacja
                </h3>
                <p className="text-sm font-light text-[#666666] leading-relaxed">{selectedProduct.specs}</p>
              </div>

              {/* Add to Cart Button */}
              <button
                onClick={addToCart}
                className="w-full py-5 bg-[#222222] text-white rounded-[12px] font-light tracking-wide hover:bg-[#333333] transition-all duration-500 hover:shadow-ambient"
              >
                Dodaj do koszyka
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Cart Page
  const CartPage = () => {
    const deliveryCost = 49;
    const subtotal = getSubtotal();
    const total = subtotal + deliveryCost;

    return (
      <div className="min-h-screen pt-32 pb-24 bg-white">
        <div className="max-w-7xl mx-auto px-6 sm:px-12 lg:px-16">
          <button
            onClick={() =>
              selectedCategory ? setView('products') : setView('categories')
            }
            className="flex items-center gap-3 text-[#666666] hover:text-[#222222] mb-16 transition-colors duration-500 font-light"
          >
            <ArrowLeft className="w-5 h-5" />
            Kontynuuj zakupy
          </button>

          <h1 className="text-4xl sm:text-5xl font-extralight tracking-tight text-[#222222] mb-16">Koszyk</h1>

          {cart.length === 0 ? (
            <div className="text-center py-24">
              <ShoppingCart className="w-20 h-20 text-[#E5E5E0] mx-auto mb-6" />
              <p className="text-base font-light text-[#666666] mb-10">Twój koszyk jest pusty</p>
              <button
                onClick={() => setView('categories')}
                className="px-10 py-4 bg-[#222222] text-white rounded-[12px] font-light tracking-wide hover:bg-[#333333] transition-all duration-500"
              >
                Przeglądaj kolekcje
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
              {/* Left - Cart Items */}
              <div>
                <h2 className="text-lg font-light text-[#222222] mb-8">Podsumowanie</h2>
                <div className="space-y-6">
                  {cart.map((item) => (
                    <div
                      key={`${item.id}-${item.color}-${item.size}-${item.finish}`}
                      className="flex gap-6 bg-[#F7F7F5] rounded-[12px] p-6"
                    >
                      <div
                        className="w-28 h-28 rounded-[12px] bg-cover bg-center flex-shrink-0"
                        style={{ backgroundImage: `url("${item.product.images[0]}")` }}
                      />
                      <div className="flex-1">
                        <h3 className="font-light text-[#222222] text-lg">{item.product.title}</h3>
                        <p className="text-sm font-light text-[#999999] mt-2">Kolor: {item.color}</p>
                        <p className="text-sm font-light text-[#999999]">Rozmiar: {item.size}</p>
                        <p className="text-sm font-light text-[#999999]">Wykończenie: {item.finish}</p>
                        <p className="text-sm font-light text-[#999999]">Ilość: {item.quantity}</p>
                        <p className="font-normal text-[#222222] mt-3 text-lg">
                          {item.product.price * item.quantity} zł
                        </p>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.id, item.color, item.size, item.finish)}
                        className="self-start p-2 text-[#CCCCCC] hover:text-[#222222] transition-colors duration-500"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="mt-10 pt-10 border-t border-[#EBEBE7] space-y-4">
                  <div className="flex justify-between text-sm font-light text-[#666666]">
                    <span>Wartość produktów</span>
                    <span>{subtotal} zł</span>
                  </div>
                  <div className="flex justify-between text-sm font-light text-[#666666]">
                    <span>Koszt dostawy (49 zł)</span>
                    <span>{deliveryCost} zł</span>
                  </div>
                  <div className="flex justify-between text-xl font-light text-[#222222] pt-4">
                    <span>Razem do zapłaty</span>
                    <span>{total} zł</span>
                  </div>
                </div>
              </div>

              {/* Right - Checkout Form */}
              <div className="bg-[#F7F7F5] rounded-[12px] p-10">
                <h2 className="text-lg font-light text-[#222222] mb-10">Dane do wysyłki</h2>

                <div className="space-y-6">
                  <div>
                    <label className="block text-xs font-light tracking-[0.15em] text-[#222222] uppercase mb-3">
                      Imię i nazwisko
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-5 py-4 bg-white border border-[#E8E8E4] rounded-[12px] text-sm font-light text-[#222222] focus:border-[#222222] focus:ring-0 transition-all duration-500"
                      placeholder="Jan Kowalski"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-light tracking-[0.15em] text-[#222222] uppercase mb-3">E-mail</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-5 py-4 bg-white border border-[#E8E8E4] rounded-[12px] text-sm font-light text-[#222222] focus:border-[#222222] focus:ring-0 transition-all duration-500"
                      placeholder="jan@example.com"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-light tracking-[0.15em] text-[#222222] uppercase mb-3">Telefon</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-5 py-4 bg-white border border-[#E8E8E4] rounded-[12px] text-sm font-light text-[#222222] focus:border-[#222222] focus:ring-0 transition-all duration-500"
                      placeholder="+48 123 456 789"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-light tracking-[0.15em] text-[#222222] uppercase mb-3">
                      Adres dostawy
                    </label>
                    <textarea
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full px-5 py-4 bg-white border border-[#E8E8E4] rounded-[12px] text-sm font-light text-[#222222] focus:border-[#222222] focus:ring-0 transition-all duration-500 resize-none"
                      rows={3}
                      placeholder="ul. Przykładowa 10/20, 00-001 Warszawa"
                    />
                  </div>
                </div>

                {/* Payment Methods */}
                <h3 className="text-xs font-light tracking-[0.2em] text-[#222222] uppercase mt-12 mb-6">
                  Metoda płatności
                </h3>
                <div className="grid grid-cols-3 gap-4">
                  {['BLIK', 'Karta płatnicza', 'Przelew'].map((method) => (
                    <button
                      key={method}
                      onClick={() => setSelectedPayment(method)}
                      className={`p-5 rounded-[12px] text-sm font-light transition-all duration-500 ${
                        selectedPayment === method
                          ? 'bg-[#222222] text-white'
                          : 'bg-white border border-[#E8E8E4] text-[#222222] hover:border-[#222222]'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>

                {/* Place Order Button */}
                <button
                  onClick={handleCheckout}
                  disabled={
                    !formData.name ||
                    !formData.email ||
                    !formData.phone ||
                    !formData.address ||
                    !selectedPayment
                  }
                  className="w-full mt-12 py-5 bg-[#222222] text-white rounded-[12px] font-light tracking-wide hover:bg-[#333333] transition-all duration-500 hover:shadow-ambient disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:bg-[#222222] disabled:hover:shadow-none"
                >
                  Zamawiam i płacę
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  // Thank You Modal
  const ThankYouModal = () => (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/40 backdrop-blur-sm">
      <div className="bg-white rounded-[12px] p-12 max-w-md w-full text-center shadow-ambient animate-in fade-in zoom-in duration-500">
        <div className="w-20 h-20 bg-[#F7F7F5] rounded-full flex items-center justify-center mx-auto mb-8">
          <Check className="w-10 h-10 text-[#222222]" />
        </div>
        <h2 className="text-2xl font-extralight tracking-tight text-[#222222] mb-6">Dziękujemy za zamówienie!</h2>
        <p className="text-sm font-light text-[#666666] mb-10 leading-relaxed">
          Potwierdzenie zostało wysłane na Twój e-mail.
        </p>
        <button
          onClick={closeThankYou}
          className="px-12 py-4 bg-[#222222] text-white rounded-[12px] font-light tracking-wide hover:bg-[#333333] transition-all duration-500"
        >
          Zamknij
        </button>
      </div>
    </div>
  );

  // Main Render
  return (
    <div className="min-h-screen flex flex-col bg-white">
      {view !== 'home' && <Header />}

      <main className="flex-1">
        {view === 'home' && <HomePage />}
        {view === 'categories' && <CategoriesPage />}
        {view === 'custom-kitchen' && <CustomKitchenPage />}
        {view === 'products' && <ProductsPage />}
        {view === 'product-detail' && <ProductDetailPage />}
        {view === 'cart' && <CartPage />}
      </main>

      {view !== 'home' && <Footer />}

      {showThankYou && <ThankYouModal />}
    </div>
  );
}

export default App;
